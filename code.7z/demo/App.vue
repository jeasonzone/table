<template>
  <div class="main-container">
    <TestTable :test="test" :columns="arr" :data="dataList"></TestTable>
  </div>
</template>

<script lang="ts">
import { TestTable } from "../src/table";
import { defineComponent, reactive, ref } from "@vue/composition-api";

export default defineComponent({
  name: "App",
  components: {
    TestTable,
  },
  setup() {
    const test = ref(true);
    let arr = reactive(["name", "power"]);
    let dataList = reactive([
      { name: "Chuck Norris", power: 1000 },
      { name: "Bruce Lee", power: 2000 },
      { name: "Jackie Chan", power: 3000 },
      { name: "Jet Li", power: 4000 },
      { name: "Jet Li", power: 5000 },
      { name: "Jet Li", power: 6000 },
      { name: "Jet Li", power: 7000 },
      { name: "Jet Li", power: 8000 },
      { name: "Jet Li", power: 9000 },
      { name: "Jet Li", power: 10000 },
      { name: "Jet Li", power: 11000 },
      { name: "Jet Li", power: 12000 },
    ]);

    return { test, arr, dataList };
  },
});
</script>
