/**
 * Created by uedc on 2021/10/11.
 */

import TestTable from './table.vue'

export { TestTable }
